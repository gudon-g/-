// ==UserScript==
// @name         咕咚一键云班课
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  咕咚一键云班课：一键刷云班课,鼠标点击课程的作业自动刷完，无需一个一个点击查看，自动加速视频，自动下载文件，自动打开文件
// @author       咕咚 微信/QQ：1436619325
// @include      https://www.mosoteach.cn/web/index.php?c=*
// @include      https://www.mosoteach.cn/web/index.php?c=interaction&m=index&clazz_course_id=*
// @grant        GM_setValue
// @grant        GM_getValue
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_addValueChangeListener
// @grant        GM_deleteValue
// @require      https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js
// @require      https://cdn.jsdelivr.net/npm/vue/dist/vue.js
// @require      https://static.runoob.com/assets/jquery/jquery.growl/javascripts/jquery.growl.js
// @require      https://ajax.aspnetcdn.com/ajax/jquery.ui/1.12.1/jquery-ui.min.js
// @require      https://use.fontawesome.com/c308119ab8.js
// @resource     mycssa https://ajax.aspnetcdn.com/ajax/jquery.ui/1.12.1/themes/blitzer/jquery-ui.css
// @resource     mycss https://static.runoob.com/assets/jquery/jquery.growl/stylesheets/jquery.growl.css
// @icon         https://i.loli.net/2021/02/16/ztKJOuGlBi2ehnR.png
// @icon64       https://i.loli.net/2021/02/16/ztKJOuGlBi2ehnR.png

// ==/UserScript==

(function() {
    GM_addStyle(GM_getResourceText('mycssa'));
    GM_addStyle(GM_getResourceText('mycss'));
    console.log(GM_getValue('myName'))
    GM_addValueChangeListener('myName', function(name, old_value, new_value, remote){
      console.log(` 发生变化的存储名是: ${name}, ${name} 原来的值是 ${old_value}, ${name} 新的值是 ${new_value}, 这个值的变动是由${remote ? '本标签页' : '其他标签页'}起的。 `);
    })
    if(GM_getValue('myName')){
         console.log(his_name);
    }else{
       var my_name=GM_setValue('myName', 0);
       var his_name = GM_getValue('myName');
       console.log(his_name);
    }

/**
 * @function：html样式插入
 */
		$("<link  rel='stylesheet' type='text/css' href='https://ajax.aspnetcdn.com/ajax/jquery.ui/1.12.1/themes/blitzer/jquery-ui.css'/>").appendTo($("head"));
		$("<div id='gudong'><div id='centerw'style=''><div class='titles' tabindex='0'><div id='course'>课程:<span>ฅʕ•̫͡•ʔฅ</span></div><div id='numbers'>作业任务:<span>0</span></div><a id='gos' href=''>GO</a></div></div><div class='logoa' ><img id='melogo' class='f' src='' alt=''><canvas id='c' class='f'>当前浏览器不支持canvas 请升级！</canvas></div></div><div id='mydialog' title='使用说明：'><h4>使用方法：</h4><h5>点击GO按钮即可！自动运行完成后自动停止！</h5><h4>作者声明：</h4><h5>一键云班课由“咕咚”独立开发,为同学带来方便,此功能完全免费,如果有盗卖现象,请立马退货退款后拉黑。</h5><h4>使用技巧：</h4><h5>鼠标在头像里：隐藏任务栏和按钮</h5><h5>鼠标在头像外：显现任务栏和按钮</h5><h5>鼠标双击头像：可以查看当前作业进度</h5><h5>鼠标点击进度条：返回默认状态</h5><h5>鼠标点击任务栏：显示使用说明</h5><h5>鼠标按住头像不放：可移动图标位置</h5><h4>使用问题：</h4><h5>1, Word、Excel、PowerPoint等演示文件无法自动完成：请把云班课弹出式窗口和重定向权限设置为允许。捷径：浏览器的搜索框最左侧的拦截弹出式窗口设置为始终允许。路径：设置—隐私设置和安全性—网站设置—近期活动—www.mosoteach.cn—权限—弹出式窗口和重定向</h5><h5>2,插件自动运行后发现还有作业没有自动刷完：以为你的网路速度太慢所导致，更换网路，刷新网页页面重新点击GO按钮或者选择其他模式点击GO按钮</h5><h4>捐赠作者：</h4><h5>制作不易，你的支持是作者最大动力，谢谢！</h5><img class='jz' src='https://i.loli.net/2021/03/03/c3yqplLIwNnOHY5.png'><img class='jz' src='https://i.loli.net/2021/03/03/XajrHbTJnkFypB6.jpg'><span></span></div>").appendTo($("body"));

/**
 * @function：css样式设置
 */
		$("#gudong").css({
			"position": "fixed",
			"width": "192px",
			"height": "60px",
			"left": "22px",
			"top":"80px"
		});
		$("#centerw").css({
			"width":" 140px",
			"height":"100%",
			"position": "absolute",
			"margin-left":"30px",
			"overflow":"hidden"
		});
		$(".logoa").css({
			"width": "60px",
			"height": "100%",
			"border-radius": "50%",
			"perspective":"120px"
		});
		$(".f").css({
			"width": "100%",
			"height":  "100%",
			"position": "absolute",
			"transition": "2s",
		'transform':'rotateY(180deg)'
		});
		$("#c").css({
			"backface-visibility": "hidden",
			 "width": "56px",
			 "height": "56px",
			 "background": "white",
			"border": "2px solid #40B782",
			"border-radius":"50%"
		});
		$(".titles").css({
			"position": "absolute",
			"top": "10px",
			"width":"100%",
			"height": "43px",
			"border-radius": "0px 20px 20px 0px",
			"background": "#40B782",
			"color": "white"
		});
		$(".titles div").css({
			"margin-left":" 30px",
			"font":"10px/21.5px '微软雅黑'",
			"height": "50%",
			"overflow":"hidden"
		});
		$(".titles span").css("vertical-align","baseline");
		$("#gos").css({
			"position": "absolute",
			"top":" 0px",
			"right": "0px",
			"width": "43px",
			"height": "100%",
			"border-radius":"50%",
			"text-align":" center",
			"line-height":"43px",
			"text-decoration": "none",
			"color": "white",
			"background": "linear-gradient(120deg,#28F39D, #09B4E3)",
			"box-shadow":"1px -2px 10px white",
		});
		$("#pass").css({
			"padding":"0px",
			"width":"100%",
			"height":"33px"
		})
	$("#bang").css('color','pink')
    $(".jz").css("width","100px")
	/**
	 * @function：获取用户头像
	 */
		$("#melogo").css("border-radius","50%").attr('src',$(".user-information-box").children("a").eq(0).children("img").attr('src'));

/**
 * @function：插件鼠标事件
 */
		var divs=document.getElementById("gudong")
		divs.onmousedown=function(){
			var ev=ev||window.event
			var x=ev.clientX-parseInt(getComputedStyle(divs,null).left)
			var y=ev.clientY-parseInt(getComputedStyle(divs,null).top)
			divs.onmousemove=function(ev){
				var ev=ev=window.event
				divs.style.left=ev.clientX-x+"px"
				divs.style.top=ev.clientY-y+"px"
			}
			divs.onmouseup=function(){
				divs.onmousemove=null
			}
			divs.onmouseleave=function(){
				divs.onmousemove=null
			}
			ev.preventDefault();
		}
		$(".logoa").children().on({
			'mouseenter':function(){
				$(".titles").animate({left:"-140px"})
			},
			'mouseleave':function(){
				$(".titles").animate({left:"0px"})
			},
			"dblclick":function(){
			$(".logoa").children().css("transform","rotateY(0deg)")
			},
			"click":function(){
				$(".logoa").children().css("transform","rotateY(180deg)")
			}
		})
		$(".titles").children("div").click(function(){
			$("#mydialog").dialog("open");
		})
		$("#gos").click(function(ev){
			var ev=ev=window.event
			if(keCheng()&&homes==$("#numbers").children("span").text()){
				if(GM_getValue('myName')){
					work()
				}else{
					$("#mydialog").dialog("open");
				}
					stopDefault(ev);
					return false;
			}
		})


	$("#mydialog").dialog({
			autoOpen:false,
			modal:true,
			width:300,
			height:250,
			resizable:false,
			draggable:false,
			buttons:{
				"取消":function(){
					$("#mydialog").dialog("close");
						GM_setValue('myName', 0)
				},
				"确定":function(){
					$("#mydialog").dialog("close");
						GM_setValue('myName', 1)
				}
			}
	})

	/**
	 * function：获取课程和作业任务
	 */
	if($(".selected .fontsize-14").text()=="资源"){
		$("#course").children("span").text($(".cc-name").children("span").text())
		var homework=$(".res-row-title")
		var homes=-1
		let box=$("#res-list-box").children("div");
		var works=new Array();
		for(let y=0;y<box.length;y++){
			works[y]=new Array();
			for(let x=0;x<box.eq(y).children(".hide-div").children("div").length;x++){
				let drag=box.eq(y).children(".hide-div").children("div").eq(x).children(".res-info").children(".create-box.manual-order-hide-part").children('span');
				if(drag.eq(drag.length-3).attr('data-is-drag')=="N"){
						$("#numbers").children("span").text(function(indexs,oldhtml){
								oldhtml=Number(oldhtml)+1
								homes=oldhtml
								return oldhtml
							})
						works[y][x]=box.eq(y).children(".hide-div").children("div").eq(x)
				}
			}
		}
		console.log(homes)
		var newData = works.filter(function(item) {
			return item.length;
		});
		works=newData;
		for(let i=0;i<works.length;i++){
			for(let j=0;j<works[i].length;j++){
					if (works[i][j]==''||works[i][j]==null||typeof(works[i][j])==undefined) {
						works[i].splice(j, 1)
						j--
					}
			}
		}
		if(homes==-1){
			$.growl.warning({
			          title: "一键云班课",
			        message: "无作业任务！！！"
			});
		}else{

		}
	}

	/**
	 * function：判断网页
	 */
		function keCheng(){
			if($("section").attr('id')=='main'){
				$.growl.notice({
						title: "一键云班课",
					message: "选择要刷的课程 路径:我加入的—课程—进入>"
				});
				return 0
			}else if($(".selected .fontsize-14").text()=="活动"){
				$.growl.notice({
						title: "一键云班课",
					message: "请选择资源才能运行"
				});
				return 0
			}else{
				return 1
			}
		}

		/**
		 * @function：阻止默认事件
		 * @name：stopDefault()
		 * @stopDefault()
		 * 	e:标签event事件
		 */
		function stopDefault(e) {
			if (e && e.preventDefault)
					e.preventDefault();
			else
					window.event.returnValue = false; //兼容IE
		}

		/**
		 * @function：自动刷作业
		 * @name：work()
		 */
	function work(){
		$.growl.notice({
				title: "一键云班课",
			message: "点击成功正在运行"
		});
		let time=0
		let speed=3000
		for(let i=0;i<=works.length-1;i++){
			setTimeout(function(){
				for(let j=0;j<works[i].length;j++){
						setTimeout(function(){
							switch (works[i][j].attr('class')){
								case "res-row-open-enable res-row preview ":
								case "res-row-open-enable res-row preview  drag-res-row":
										switch (works[i][j].attr('data-mime')){
											case "image":
												console.log("image");
												works[i][j].trigger("click");
												clicks()
												oRange+=(100/homes)
												break;
											case "audio":
												console.log("audio");
												works[i][j].trigger("click");
												oRange+=(100/homes)
												audio();
												break;
											case "video":
												console.log("video");
												works[i][j].trigger("click");
												oRange+=(100/homes)
												video();
												break;
											default:
												console.log("未知"+works[i][j].attr('class'));
												numbers()
												oRange+=(100/homes)
												break;
										}
								break;
								case "res-row-open-enable res-row preview-file  drag-res-row":
								case "res-row-open-enable res-row preview-file ":
									console.log("application");
									works[i][j].trigger("click");
									numbers()
									oRange+=(100/homes)
									break;
								case "res-row-open-enable res-row download-res  drag-res-row":
									console.log("text");
									works[i][j].children(".operation.manual-order-hide-part").children("ul").children(".download-res-button").children("a")[0].click()
									oRange+=(100/homes)
									numbers()
									break;
								default:
									console.log("未知")
									console.log(works[i][j].eq(0))
									console.log(works[i][j].attr('data-mime')+" "+works[i][j].attr('class'));
									numbers()
									oRange+=(100/homes)
									break;
							}
						},j*speed)
				}
			},time+=i?works[i-1].length*speed:0)
		}
	}

	/**
	 * @function：图片类型作业
	 *
	 */
	function clicks(){
		var off=setInterval(function(){
			if($(".viewer-canvas").children().length){
					console.log("资源以加载成功")
					$(".viewer-button.viewer-close").trigger("click");
					clearTimeout(off);
			}else{
				console.log("资源以加载中")
			}
		},500)
		numbers()
	}

	/**
	 * function：作业任务量
	 */
function numbers(){
		$("#numbers").children("span").text(function(indexs,oldhtml){
			oldhtml=Number(oldhtml)-1
			if(!Number(oldhtml)){
				$.growl.notice({
						title: "一键云班课",
					message: "作业已经全部完成"
				});
			}
			return oldhtml
		})

}

/**
	 * @function：音频类型作业
	 *
	 */
	function audio(a){
		var offc=setInterval(function(){
			if(!$("#preview-audio_html5")[0].paused){
					console.log("资源以加载成功")
					$("#preview-audio_html5").trigger("pause")
					$(".close-window").trigger("click");
					clearTimeout(offc);
			}else{
				console.log("资源以加载中")
			}
		},500)
	numbers()
	}

	/**
	 * @function：视频类型作业
	 *
	 */
	function video(){
		var offa=setInterval(function(){
			if(!$("#preview-video_native_hls")[0].paused){
					console.log("资源以加载成功")
					$("#preview-video_native_hls")[0].currentTime=$("#preview-video_native_hls")[0].duration
					$("#preview-video_native_hls").trigger("pause")
					$(".close-window").trigger("click");
					clearTimeout(offa);
			}else{
				console.log("资源以加载中")
			}
		},1500)
		numbers()
	}

/**
 * @function：进度条
 */

		let canvas = document.getElementById("c")
		let ctx = canvas.getContext("2d")
		let oRange = 0
		let M = Math
		let Sin = M.sin
		let Cos = M.cos
		let Sqrt = M.sqrt
		let Pow = M.pow
		let PI = M.PI
		let Round = M.round
		let oW = canvas.width = 60
		let oH = canvas.height = 60
		let lineWidth = -1// 线宽
		let r = (oW / 2) // 大半径
		let cR = r - 10 * lineWidth
		ctx.beginPath()
		ctx.lineWidth = lineWidth

		// 水波动画初始参数
		let axisLength = 2 * r - 16 * lineWidth // Sin 图形长度
		let unit = axisLength / 9 // 波浪宽
		let range = .4 // 浪幅
		let nowrange = range
		let xoffset = 8 * lineWidth // x 轴偏移量
		let data = ~~(oRange) / 100 // 数据量
		let sp = 0 // 周期偏移量
		let nowdata = 0
		let waveupsp = 0.006 // 水波上涨速度

		// 圆动画初始参数
		let arcStack=new Array();
		arcStack = [] // 圆栈
		let bR = r - 8 * lineWidth
		let soffset = -(PI / 2) // 圆动画起始位置
		let circleLock = true // 起始动画锁

		// 获取圆动画轨迹点集
		for (var i = soffset; i < soffset + 2 * PI; i += 1 / (8 * PI)) {
		    arcStack.push([
		        r + bR * Cos(i),
		        r + bR * Sin(i)
		    ])
		}
		// 圆起始点
		let cStartPoint = arcStack.shift();
		ctx.strokeStyle = "#70E0F3";
		ctx.moveTo(cStartPoint[0], cStartPoint[1]);
		// 开始渲染
		render();

		function drawSine() {
		    ctx.beginPath();
		    ctx.save();
		    var Stack = []; // 记录起始点和终点坐标
		    for (var i = xoffset; i <= xoffset + axisLength; i += 20 / axisLength) {
		        var x = sp + (xoffset + i) / unit;
		        var y = Sin(x) * nowrange;
		        var dx = i;
		        var dy = 2 * cR * (1 - nowdata) + (r - cR) - (unit * y);
		        ctx.lineTo(dx, dy);
		        Stack.push([dx, dy])
		    }
		    // 获取初始点和结束点
		    var startP = Stack[0]
		    var endP = Stack[Stack.length - 1]
		    ctx.lineTo(xoffset + axisLength, oW);
		    ctx.lineTo(xoffset, oW);
		    ctx.lineTo(startP[0], startP[1])
		    ctx.fillStyle = "#70E0F3";
		    ctx.fill();
		    ctx.restore();
		}

		function drawText() {
		    ctx.globalCompositeOperation = 'source-over';
		    var size = 0.4 * cR;
		    ctx.font = 'bold ' + size + 'px Microsoft Yahei';
				var gradient=ctx.createLinearGradient(0,0,canvas.width,0);
				gradient.addColorStop("0","magenta");
		    let txt = (nowdata.toFixed(2) * 100).toFixed(0) + '`%';
		    var fonty = r + size / 2;
		    var fontx = r - size * 0.8;
		    ctx.fillStyle = "white";
		    ctx.textAlign = 'center';
				ctx.strokeStyle="#5F6368";
				ctx.strokeText(txt, r + 5, r + 20)
		    ctx.fillText(txt, r + 5, r + 20)
		}

		//橘黄色进度圈
		function orangeCircle() {
		    ctx.beginPath();
		    ctx.strokeStyle = '#70E0F3';
		    //使用这个使圆环两端是圆弧形状
		    ctx.lineCap = 'round';
		    ctx.arc(r, r, cR - 5, 0 * (Math.PI / 180.0) - (Math.PI / 2), (nowdata * 360) * (Math.PI / 180.0) - (Math.PI / 2));
		    ctx.stroke();
		    ctx.save()
		}
		//裁剪中间水圈
		function clipCircle() {
		    ctx.beginPath();
		    ctx.arc(r, r, cR - 10, 0, 2 * Math.PI, false);
		    ctx.clip();
		}
		//渲染canvas
		function render() {
		    ctx.clearRect(0, 0, oW, oH);
		   //橘黄色进度圈
		    orangeCircle();
		    //裁剪中间水圈
		    clipCircle();
		    // 控制波幅
		//  oRange.addEventListener("change", function() {
		        data = ~~(oRange) / 100;
		//  }, 0);
		    if (data >= 0.85) {
		        if (nowrange > range / 4) {
		            var t = range * 0.01;
		            nowrange -= t;
		        }
		    } else if (data <= 0.1) {
		        if (nowrange < range * 1.5) {
		            var t = range * 0.01;
		            nowrange += t;
		        }
		    } else {
		        if (nowrange <= range) {
		            var t = range * 0.01;
		            nowrange += t;
		        }
		        if (nowrange >= range) {
		            var t = range * 0.01;
		            nowrange -= t;
		        }
		    }
		    if ((data - nowdata) > 0) {
		        nowdata += waveupsp;
		    }
		    if ((data - nowdata) < 0) {
		        nowdata -= waveupsp
		    }
		    sp += 0.07;
		    // 开始水波动画
		    drawSine();
		    // 写字
		    drawText();
		    requestAnimationFrame(render)
		}

})();